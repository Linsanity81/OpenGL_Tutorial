///=========================================================================================///
///
///                       Functions to be filled in for Assignment 2   
///
///           IMPORTANT: you ONLY need to work on functions with TODO in this section    
///    
///=========================================================================================///


#include "SkeletalModel.h"


///=========================================================================================///
///                                    Load .skel File    
///=========================================================================================///


// TODO: Load the skeleton from file here, create hierarchy of joints
//       (i.e., set values for m_rootJoint and m_joints)
void SkeletalModel::loadSkeleton( const char* filename )
{
    ifstream fileInput;
    fileInput.open(filename);
    
    char buffer[1000];
    float translation14;
    float translation24;
    float translation34;
    int parentIndex;
    
    vector<Joint *> listOfJoints;
    vector<int> parentIndexList;
    
    cout<< "LoadSkeleton is called, parsing input" << endl;
    if (fileInput.is_open())
    {
        while (fileInput.getline(buffer, 1000))
        {
            stringstream ss(buffer);
            ss >> translation14;
            ss >> translation24;
            ss >> translation34;
            ss >> parentIndex;
            
            //this is the matrix for joint transformation, the translation component only because it doesn't scale
            glm::mat4 translationMatrix = glm::mat4(1, 0, 0, translation14, 0, 1, 0, translation24, 0, 0, 1, translation34, 0, 0, 0, 1);
            
            Joint* joint = new Joint;
            joint->transform = translationMatrix;
            
            if (parentIndex < 0)
            {
                cout << "Parent Index found: " << parentIndex << endl;

                m_rootJoint = joint;
            }
            
            listOfJoints.push_back(joint);
            
            //parents are by line
            parentIndexList.push_back(parentIndex); 
        }
    }
    else
    {
        cout << "File not found" <<endl;
        return;
    }
    
    //Adding children
    for (int i = 0; i < parentIndexList.size(); i++)
    {
        int parentIndex = parentIndexList[i];
        cout << "the parent index is " << parentIndex << "  and  the child is " << i << std::endl;
        if (parentIndex > -0.0001)
        {    
            Joint* parentJoint = listOfJoints[parentIndex];
            Joint* childJoint = listOfJoints[i];

            //cout << "parent transform is " << endl;
            //std::cout << glm::to_string(parentJoint->transform) << std::endl;

            //cout << "child transform is "<< endl;
            //std::cout << glm::to_string(childJoint->transform) << std::endl;

            parentJoint->children.push_back(childJoint);
        }   
    }
    
    m_joints = listOfJoints;
    
    cout << "LoadSkeleton done" << endl; 
}




///=========================================================================================///
///                         Compute transformations for Joints and Bones     
///=========================================================================================///

void SkeletalModel::computeTransforms()
{
    if( m_joints.size() == 0 )
        return;

    computeJointTransforms();

    computeBoneTransforms();
}

// Compute a transformation matrix for each joint (i.e., ball) of the skeleton
void SkeletalModel::computeJointTransforms( )
{
    jointMatList.clear();

    m_matrixStack.clear();

    computeJointTransforms(m_rootJoint, m_matrixStack);
}

// TODO: You will need to implement this recursive helper function to traverse the joint hierarchy for computing transformations of the joints
void SkeletalModel::computeJointTransforms(Joint* joint, MatrixStack matrixStack)
{
    //push the transformation matrix to matrix stack (this will multiply with the last stack of matrix)
    matrixStack.push( joint->transform );

    vector<Joint*> childJoints = joint->children;

    for (int i = 0; i< childJoints.size() ; i++)
    {
        Joint* child = childJoints[i];

        computeJointTransforms(child, matrixStack);
    }

    jointMatList.push_back(matrixStack.top());

    //pop the matrix from stack
    matrixStack.pop();
}


// Compute a transformation matrix for each bone (i.e., cylinder) between each pair of joints in the skeleton
void SkeletalModel::computeBoneTransforms( )
{
    boneMatList.clear();

    m_matrixStack.clear();

    computeBoneTransforms(m_rootJoint, m_matrixStack);
}

// TODO: You will need to implement this recursive helper function to traverse the joint hierarchy for computing transformations of the bones
void SkeletalModel::computeBoneTransforms(Joint* joint, MatrixStack matrixStack)
{
    //sending current transformation matrix to the children for recursive
    matrixStack.push( joint->transform );

    vector<Joint*> childJoints = joint->children;
    
    for (int i = 0; i < childJoints.size(); i++)
    {
        Joint* child = childJoints[i];

        //transformation matrix  is from parent joint to that child joint. Later this is pushed to the stack to multiply with the rest of the transformation matrices from the root
        glm::vec3 distanceFromParents(child->transform[0][3],child->transform[1][3],child->transform[2][3]);
        double L = glm::length(distanceFromParents);

        glm::mat4 translationMatrix(1.0f);
        translationMatrix[2][3] += 0.5; //move the box by 0.5

        glm::mat4 scaleMatrix(1.0f);
        scaleMatrix[0][0] = 0.01;
        scaleMatrix[1][1] = 0.01;
        scaleMatrix[2][2] = L; //scale x and y by half so that the length is 0.25 then z by L to fill the gap between parent and children

        glm::vec3 z = glm::normalize( distanceFromParents );
        glm::vec3 y = glm::normalize( glm::cross(z, glm::vec3(0,0,1)) );
        glm::vec3 x = glm::normalize( glm::cross(y, z) );
        glm::mat4 rotationMatrix(x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, 0, 0, 0, 1);

        matrixStack.push(rotationMatrix);
        matrixStack.push(scaleMatrix);
        matrixStack.push(translationMatrix);

        //load the matrix to the list
        boneMatList.push_back(matrixStack.top());
        matrixStack.pop();
        matrixStack.pop();
        matrixStack.pop();
        computeBoneTransforms(child, matrixStack);
    }

    //Pop it when done
    matrixStack.pop();
}




///=========================================================================================///
///                              Set Joint Angles for Transform     
///=========================================================================================///

// TODO: Set the rotation part of the joint's transformation matrix based on the passed in Euler angles.
void SkeletalModel::setJointTransform(int jointIndex, float angleX, float angleY, float angleZ)
{
    //The rotation part of the joint is the 3x3 submatrix of transformation matrix
    Joint* joint = m_joints[jointIndex];
    glm::mat4 transformaMat = joint->transform;

    //RotationMatrix Setup, rotate in x, then rotate in y, then rotate in z
    glm::mat4 rotationX = glm::rotate(glm::mat4(1.0f), glm::radians(angleX), glm::vec3(1.0,0.0,0.0));
    glm::mat4 rotationY = glm::rotate(glm::mat4(1.0f), glm::radians(angleY), glm::vec3(0.0,1.0,0.0));
    glm::mat4 rotationZ = glm::rotate(glm::mat4(1.0f), glm::radians(angleZ), glm::vec3(0.0,0.0,1.0));

    glm::mat4 rotationMat = rotationZ * rotationY * rotationX;

    //transformationMatrix.setSubmatrix3x3(0, 0, rotationMatrix.getSubmatrix3x3(0, 0));
    transformaMat[0][0] = rotationMat[0][0]; transformaMat[0][1] = rotationMat[0][1]; transformaMat[0][2] = rotationMat[0][2];
    transformaMat[1][0] = rotationMat[1][0]; transformaMat[1][1] = rotationMat[1][1]; transformaMat[1][2] = rotationMat[1][2];
    transformaMat[2][0] = rotationMat[2][0]; transformaMat[2][1] = rotationMat[2][1]; transformaMat[2][2] = rotationMat[2][2];

    joint->transform = transformaMat;
}







