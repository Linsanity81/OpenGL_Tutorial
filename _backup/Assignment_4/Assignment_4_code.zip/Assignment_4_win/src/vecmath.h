#ifndef VECMATH_H
#define VECMATH_H

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

using namespace glm;

#endif // VECMATH_H
