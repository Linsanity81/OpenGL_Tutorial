#ifndef PLANE_H
#define PLANE_H

#include "Object3D.h"
#include "vecmath.h"
#include <cmath>
using namespace std;


class Plane: public Object3D
{
public:
	Plane(){}

	Plane( const vec3& normal , float d , Material* m):Object3D(m)
    {
        this->normal = normalize(normal);
        this->d = -d;
	}

	~Plane(){}

    /// TODO: implement this function for ray-plane intersection test.
	virtual bool intersect( const Ray& r , Hit& h , float tmin)
    {   
        vec3 origin = r.getOrigin();
        vec3 dir = r.getDirection();
        
        float dotnRd = dot(normal, dir);
        if (dotnRd == 0)
        {
            return false; //false because of infinite plane
        }
        
        else
        {
            float t = -1 * (d + dot(normal, origin)) / dotnRd;

            if (t > tmin && t < h.getT())
            {
                h.set(t, material,normalize( normal));
                return true;
            }
            else
            {
                return false;
            }
        }
	}

protected:
    vec3 normal;
    float d;

    
};
#endif //PLANE_H
		

