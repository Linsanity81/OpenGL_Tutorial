#ifndef SPHERE_H
#define SPHERE_H

#include "Object3D.h"
#include "vecmath.h"
#include <cmath>

#include <iostream>
using namespace std;

class Sphere: public Object3D
{
public:
	Sphere()
    { 
		//unit ball at the center
        this->center = vec3(0,0,0);
        this->radius = 1.0;
	}

	Sphere( vec3 center , float radius , Material* material ):Object3D(material)
    {
        this->center = center;
        this->radius = radius;
	}
	

	~Sphere(){}

    /// TODO: implement this function for ray-sphere intersection test.
	virtual bool intersect( const Ray& r , Hit& h , float tmin)
    {
        vec3 rayOrigin = r.getOrigin() - this->center; // this makes the sphere to be at the center of the screen
        vec3 rayDirection = r.getDirection();
        
        float a = rayDirection[0] * rayDirection[0] + rayDirection[1] * rayDirection[1] + rayDirection[2] * rayDirection[2];
        float b = dot(rayDirection, rayOrigin) * 2;
        float c = dot(rayOrigin, rayOrigin) - this->radius*this->radius;
        
        float check =( b*b) - (4 * a * c);
        
        if (check >= 0)
        { 
            // has intersection
            float tpos = (-1*b + sqrt(check)) / (2*a);
            float tneg = (-1*b - sqrt(check)) / (2*a);
            
            //check tneg first because tneg < tpos
            if (tneg > tmin && tneg < h.getT())
            { 
                // t is less  than current t, and intersection isnt behind eye
                vec3 newRay = rayOrigin + tneg*rayDirection;
                // newRay.normalize();
                h.set(tneg, material, normalize(newRay)); //the normal is at P(t) because the sphere is at origin
                return true;
            }
            
            else if (tpos > tmin && tpos < h.getT())
            {
                vec3 newRay = rayOrigin + tpos*rayDirection;
                //newRay.normalize();
                h.set(tpos, material, normalize(newRay));
                return true;
            }
        }
        
		return false;
        
	}

protected:
    vec3 center;
    float radius;
  

};


#endif
