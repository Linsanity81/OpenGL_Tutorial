#ifndef MATERIAL_H
#define MATERIAL_H

#include <cassert>
#include "vecmath.h"

#include "Ray.h"
#include "Hit.h"
#include "texture.hpp"


class Material
{
public:
	
    Material( const vec3& d_color ,const vec3& s_color=vec3(0,0,0), float s=0):
    diffuseColor( d_color),specularColor(s_color), shininess(s)
    {

    }

    virtual ~Material()
      {

      }

    virtual vec3 getDiffuseColor() const 
    { 
      return  diffuseColor;
    }
      
    /// TODO: Implement this function to compute diffuse and specular components of Phong lighting 
    vec3 Shade( const Ray& ray, const Hit& hit, const vec3& dirToLight, const vec3& lightColor ) 
    {
        //doing diffuse shading
        vec3 diffuseShade;
        vec3 normal = normalize(hit.getNormal());
        float diffuseDot = dot(normal, dirToLight);
        
        //clamping
        if (diffuseDot < 0)
        {
            diffuseDot = 0;
        }
        
        //get diffuse reflection constant from texture
        if (t.valid())
        {
            //changing diffuse color based on texture
            vec3 color = t(hit.texCoord[0], hit.texCoord[1]);
            diffuseColor = color;
            diffuseShade = diffuseDot *  vec3(lightColor[0] * diffuseColor[0],lightColor[1]*diffuseColor[1],lightColor[2]*diffuseColor[2]);
        }
        else
        {
            diffuseShade = diffuseDot * vec3(lightColor[0] * diffuseColor[0],lightColor[1]*diffuseColor[1],lightColor[2]*diffuseColor[2]);
        }
        
        //doing specular shading
        vec3 specularShade;
        vec3 v = ray.getDirection()*-1.0f;
        vec3 r = normalize(2.0f*diffuseDot * normal - dirToLight);
        float speculardot = dot(v,r);
        if (speculardot < 0)
        {
            speculardot = 0;
        }
        
        specularShade =  pow(speculardot, shininess)* vec3( specularColor[0]* lightColor[0], specularColor[1] * lightColor[1], specularColor[2] * lightColor[2]);;
        
        return diffuseShade + specularShade;
    }

    void loadTexture(const char * filename)
    {
      t.load(filename);
    }

    Texture t;

 protected:
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};



#endif // MATERIAL_H
